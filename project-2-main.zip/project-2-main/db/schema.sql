DROP DATABASE IF EXISTS musiposium_db;

CREATE DATABASE musiposium_db;